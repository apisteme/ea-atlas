# Licence

```
MIT License

Copyright (c) 2026 Prashant Nema

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

# Third-party notices

- **ArchiSurance sample model** (`assets/Archisurance.archimate.xml`) is taken from the test data of Archi, the open source ArchiMate modelling tool (https://github.com/archimatetool/archi), distributed under the MIT licence. ArchiSurance is a fictional insurer created by The Open Group to illustrate ArchiMate. The example atlas adds illustrative content that is not part of the Archi model or The Open Group case study.
- **Industry standards.** Pack capability models are written in the pack's own words. They record the names of BIAN service domains, ACORD-style insurance domains and APQC PCF categories as references only. These standards are owned by their publishers and have their own licence terms; check them before republishing their content.
- **Regulation summaries** are paraphrased from the cited public sources and are not legal advice. Dates marked "to confirm" or "estimate" must be checked against the final texts.
