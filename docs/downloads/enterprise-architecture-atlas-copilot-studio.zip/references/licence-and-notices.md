# Licence for content

Copyright (c) 2026 Episteme Partners Ltd.

Except where noted below, the content of EA Atlas is licensed under the **Creative Commons Attribution 4.0 International licence (CC BY 4.0)**: https://creativecommons.org/licenses/by/4.0/ (full legal code: https://creativecommons.org/licenses/by/4.0/legalcode).

Content means everything that is not source code, including:

- the skill instructions (`SKILL.md` files) and the kits in `kits/`
- the industry packs in `packs/` (capability models, roles, journeys, processes, regulation summaries, glossaries)
- the reference documents, guides, README files and the website in `docs/` and `site/`
- the example atlases, dashboards, Excel repositories and atlas files built from them

You may share and adapt the content for any purpose, including commercial use, as long as you give appropriate credit, provide a link to the licence and indicate if changes were made. Suggested credit:

> EA Atlas by Episteme Partners (https://www.epistemepartners.com), licensed under CC BY 4.0.

## Source code

Source code (`.py`, `.js` and the dashboard template) is licensed under the MIT licence in `LICENSE`, so it can be reused in software projects without the attribution terms of CC BY.

## Third-party material

Third-party material keeps its own licence and is not covered by this file. See `NOTICE.md`, in particular the ArchiSurance sample model from Archi (MIT licence).

## MIT licence (source code)

```
MIT License

Copyright (c) 2026 Episteme Partners Ltd

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

# Notices

EA Atlas is an open project by Episteme Partners Ltd (https://www.epistemepartners.com). Code is licensed under MIT (`LICENSE`); content is licensed under CC BY 4.0 (`LICENSE-CONTENT.md`). The material below keeps its own terms.

- **ArchiSurance sample model** (`assets/Archisurance.archimate.xml`) is taken from the test data of Archi, the open source ArchiMate modelling tool (https://github.com/archimatetool/archi), distributed under the MIT licence. ArchiSurance is a fictional insurer created by The Open Group to illustrate ArchiMate. The example atlas adds illustrative content that is not part of the Archi model or The Open Group case study.
- **Industry standards.** Pack capability models are written in the pack's own words. They record the names of BIAN service domains, ACORD-style insurance domains and APQC PCF categories as references only. These standards are owned by their publishers and have their own licence terms; check them before republishing their content.
- **Regulation summaries** are paraphrased from the cited public sources and are not legal advice. Dates marked "to confirm" or "estimate" must be checked against the final texts.
